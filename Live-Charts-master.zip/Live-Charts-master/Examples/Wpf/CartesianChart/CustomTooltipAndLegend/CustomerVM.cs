﻿namespace Wpf.CartesianChart.CustomTooltipAndLegend
{
    public class CustomerVm
    {
        public string Name { get; set; }
        public string LastName { get; set; }
        public int Phone { get; set; }
        public int PurchasedItems { get; set; }
    }
}
