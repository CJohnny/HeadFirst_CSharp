﻿using System.Windows.Controls;

namespace Wpf.CartesianChart.ThreadSafe
{
    /// <summary>
    /// Interaction logic for TreadSafeExample.xaml
    /// </summary>
    public partial class ThreadSafeExample : UserControl
    {
        public ThreadSafeExample()
        {
            InitializeComponent();
        }
    }
}
